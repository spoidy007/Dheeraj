package form;

public class central {
	static String from_station;
	static String to_station;

	public static void main(String[] args) {
		System.out.println(central.from_station);
		System.out.println(central.to_station);

	}

}
