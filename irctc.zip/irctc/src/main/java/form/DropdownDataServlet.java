package form;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/dropdownData")
public class DropdownDataServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			// Connect to the database
			Class.forName("org.postgresql.Driver");
			
			conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres",
					"postgres", "localhost");

			// Query to fetch dropdown data from the database
			String query = "SELECT * from sz_railway";
			stmt = conn.prepareStatement(query);
			rs = stmt.executeQuery();

			// Construct JSON-formatted string manually
			StringBuilder jsonBuilder = new StringBuilder();
			jsonBuilder.append("[");
			boolean first = true;
			while (rs.next()) {
				if (!first) {
					jsonBuilder.append(",");
				}
				jsonBuilder.append("{");
				jsonBuilder.append("\"id\":").append(rs.getInt("id")).append(",");
				jsonBuilder.append("\"name\":\"").append(rs.getString("name")).append("\"");
				jsonBuilder.append("}");
				first = false;
			}
			jsonBuilder.append("]");

			// Set response content type to JSON
			response.setContentType("application/json");

			// Write JSON response
			PrintWriter out = response.getWriter();
			out.print(jsonBuilder.toString());
			out.flush();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// Close all resources
			try {
				if (rs != null)
					rs.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				if (stmt != null)
					stmt.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
