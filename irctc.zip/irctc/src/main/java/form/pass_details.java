package form;

import java.io.BufferedReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@WebServlet("/passdetails")
public class pass_details extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PreparedStatement ps = null;
		int flag = 0;
		response.setContentType("text/html");

		try {
			Class.forName("org.postgresql.Driver");
			Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres",
					"postgres", "localhost");
			
			BufferedReader reader = request.getReader();
			StringBuilder rb = new StringBuilder();
			String line;
			while ((line = reader.readLine()) != null) {
				rb.append(line);
			}
			reader.close();
			String jsonstring = rb.toString();
			// System.out.println(jsonstring);
			JSONArray jarray = new JSONArray(jsonstring);
			for (int i = 0; i < jarray.length(); i++) {
				JSONObject jobj = jarray.getJSONObject(i);
				String fname = jobj.getString("fullname");
				int age = jobj.getInt("age");
				String gender = jobj.getString("gender");
				String berth = jobj.getString("Berth_preference");
				ps = con.prepareStatement("insert into sz_passenger values(?,?,?,?)");
				ps.setString(1, fname);
				ps.setInt(2, age);
				ps.setString(3, gender);
				ps.setString(4, berth);
				int j = ps.executeUpdate();
				if (j > 0) {
					flag = 1;
					System.out.println("data entered");
				}
			}
			System.out.println(flag);
			if (flag == 1) {
				// response.sendRedirect("success.html");
				// request.getRequestDispatcher("success.html").forward(request, response);
				response.getWriter().println("<script>window.location.href = 'success.html;</script>");
			}

		} catch (ClassNotFoundException | SQLException | JSONException e) {
			e.printStackTrace();
		}
	}

}
