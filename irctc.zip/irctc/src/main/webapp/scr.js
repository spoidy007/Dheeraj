var data;
$(document).ready(function() {
	
	
		    $.getJSON('trains_data', function(data) {
		        $.each(data, function(index, station) {
		            $('#from').append($('<option>', {
		                value: station.station, 
		                text: station.stn_name 
		            }));
		            $('#to').append($('<option>', {
		                value: station.station, 
		                text: station.stn_name
		            }));
		        });
		    });
		
		    // Handle the button click to send data to the servlet
		    $('#btn').click(function() {
		        var fromValue = $('#from').val();
		        var toValue = $('#to').val();
		        $.ajax({
		            url: 'searchservlet',
		            type: 'POST',
		            data: { fromt: fromValue, tot: toValue },
		            success: function(response) {
		                process(response);
		            },
		            error: function(xhr, status, error) {
		                console.error('Error sending data to servlet:', error);
		            }
		        });
		    });
		    
		    //DATE PICKER
		    var today = new Date();
    		today.setUTCHours(0, 0, 0, 0);
		    var datePicker = document.getElementById('datePicker');
		    if (datePicker) {
		        datePicker.min = today.toISOString().split('T')[0];
		    } else {
		        console.error("Element with ID 'datePicker' not found.");
		    }
		    
		    // AJAX request to load table.html content
		   $("#reservationForm").submit(function(event) {
            event.preventDefault();

            
		            $.ajax({
		                url: "table.html",
		                method: "GET",
		                success: function(data) {
		                    $("#tablecontent").html(data);
		                },
		                error: function(xhr, status, error) {
		                    console.error("Error loading table.html:", error);
		                }
		            });
		        });
		   $("#tableForm").submit(function(event) {
			   //window.alert("hi bro")
			   //console.log("hi bro");
			    event.preventDefault(); 
			    var table = document.getElementById("passenger-details-table");
	            var data = [];
	             for (var i = 1; i < table.rows.length; i++) {
	                var row = table.rows[i];
	                var rowData = {};
	                for (var j = 0; j < row.cells.length; j++) {
	                    var cell = row.cells[j];
	                    var fieldName = cell.children[0].name;
	                    var cellData = cell.children[0].value;
	                    rowData[fieldName] = cellData;
	                }
	                data.push(rowData);
	            }
            
	            $.ajax({
	                url: 'passdetails',
	                type: 'POST',
	                contentType: 'application/json',
	                data: JSON.stringify(data),
	                success: function(response) {
	                    //console.log('Data sent successfully:', response);
	                    
	                },
	                error: function(xhr, status, error) {
	                    console.error('Error sending data to servlet:', error);
	                }
	            });
		});
		});
		
		// Function to process the response data and populate the "train" dropdown
		function process(response) {
		    // Clear existing options in the "train" dropdown
		    //$('#train').empty();
		    $.each(response, function(index, train) {
		        $('#train').append($('<option>', {
		            value: train.trainname,
		            text: train.id + " - " + train.trainname
		        }));
		    });
		}

		//TABLE.HTML
		function addRow() {
	        var table = document.getElementById("passenger-details-table");
	        var newRow = table.insertRow(-1); // Insert new row at the end of the table
	        
	        var cell1 = newRow.insertCell(0);
	        var cell2 = newRow.insertCell(1);
	        var cell3 = newRow.insertCell(2);
	        var cell4 = newRow.insertCell(3);
	
	        cell1.innerHTML = "<input type='text' name='fullname' id='tablename'>";
	        cell2.innerHTML = "<input type='number' name='age' min='0' id='tableage'>";
	        cell3.innerHTML = `<select name='gender' id='tableselect'>
	                            <option value='male'>Male</option>
	                            <option value='female'>Female</option>
	                            <option value='other'>Other</option>
	                          </select>`;
	        cell4.innerHTML = `<select name='berth_preference' id='tableselect'>
	                            <option value='lower'>Lower</option>
	                            <option value='middle'>Middle</option>
	                            <option value='upper'>Upper</option>
	                           </select>`;
    	}
	    
    	function deleteRow() {
			    var table = document.getElementById("passenger-details-table");
			    var lastRow = table.rows.length - 1;
			    if (lastRow > 1) { // Ensure there is at least one row (excluding the header)
			        table.deleteRow(lastRow); // Delete the last row
			    } 
			    else {
			        console.log("Cannot delete header row.");
			        window.alert("Atleast one passenger is required!")
			    }
			}
			
		document.getElementById("confirm").onclick = function() {
			window.alert("Thankyou!! You have successfully booked the Tickets")
    		window.location.href = "success.html"
};
    
